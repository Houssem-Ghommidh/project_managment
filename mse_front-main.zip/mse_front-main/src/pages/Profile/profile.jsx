import React from 'react'

const Profile = () => {
  return (
    <div>
      Hello
    </div>
  )
}

export default Profile
